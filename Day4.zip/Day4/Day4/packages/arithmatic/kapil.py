n1=100
def add(a, b):
    print("The Addition is:" ,a+b)

def sub(a,b):
    print ("The Substraction:", a-b)