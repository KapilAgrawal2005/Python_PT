# import  kapil 
# kapil.add (10, 20)
# kapil.sub (22,11)
# print(kapil.n1)

# import  kapil  as c
# c.add (10, 20)
# c.sub (22,11)
# print(c.n1)

# from kapil import add, sub, n1 
# add (10, 20)
# sub (22,11)
# print(n1)

# from kapil import *
# add (10, 20)
# sub (22,11)
# print(n1)


from Day4.packages.arithmatic.kapil import *
add (10, 20)
sub (22,11)
print(n1)


